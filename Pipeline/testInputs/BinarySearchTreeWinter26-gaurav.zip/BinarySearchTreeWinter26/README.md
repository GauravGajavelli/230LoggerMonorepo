# BinarySearchTree
Starter code for the binary search trees assignment.
