package testSupport;

public enum FileIgnoreReasons {
GENERIC,
TOO_LARGE,
}
