package testSupport;

public enum TestStatus {
SUCCESSFUL,
FAILED,
ABORTED,
DISABLED,
}
