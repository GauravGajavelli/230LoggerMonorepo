package bstStarter;

import java.util.ArrayList;


/**
 *
 * Exam 2. Tree methods.
 * 
 * @author <<YOUR NAME HERE>>
 */

/*
 * TODO: Directions: Implement the methods below. See the paper for details.
 */
public class BinarySearchTree {

	Node root;

	// The -123 is arbitrary -any String would be fine since we never refer to it.
	final Node NULL_NODE = new Node("-123");

	public BinarySearchTree() {
		root = NULL_NODE;
	}

	
	/**
	 * 
	 * See the written document for more details.
	 * 
	 */
	public int countLeftNodesAtDepth(int depth) {
		// TODO: Write this.
		return -1;
	}
	
	/**
	 *  
	 * See the written document for more details.
	 * 
	 */
	public String shortestWordAlongPath(String target)
	{
		// TODO: Write this.
		return "";
	}
	
	/**
	 *  
	 * See the written document for more details.
	 * 
	 */
	public void pruneFullSubtreesSize3() {
		throw new UnsupportedOperationException("TODO: delete this statement and implement this operation.");
	}



	// The next methods are used by the unit tests
	public void insert(String e) {
		this.root = this.root.insert(e);
	}

	@Override
	public String toString() {
		return toInorderList().toString();
	}

	public Object[] toInorderArray() {
		return toInorderList().toArray();
	}

	public Object[] toPreorderArray() {
		return toPreorderList().toArray();
	}

	ArrayList<String> toInorderList() {
		ArrayList<String> list = new ArrayList<>();
		this.root.toInorderList(list);
		return list;
	}

	ArrayList<String> toPreorderList() {
		ArrayList<String> list = new ArrayList<>();
		this.root.toPreorderList(list);
		return list;
	}


	/**
	 * Feel free to call from tests to use to verify the shapes of your trees while
	 * debugging. Just remove the calls you are done so the output isn't cluttered.
	 * 
	 * @return A string showing a traversal of the nodes where children are indented
	 *         so that the structure of the tree can be determined.
	 * 
	 */
	public String toIndentString() {
		return root.toIndentString("");
	}
	
	
	// /////////////// BinaryNode
	public class Node {

		public String data;
		public Node left;
		public Node right;

		public Node(String element) {
			this.data = element;
			this.left = NULL_NODE;
			this.right = NULL_NODE;
		}


		public int getHeight() {
			return (this == NULL_NODE) ? -1 : Math.max(left.getHeight(), right.getHeight()) + 1;
		}
		


		// -------------------------------------------------------------
		// Below used by unit tests

		public void toInorderList(ArrayList<String> list) {
			if (this == NULL_NODE) {
				return;
			}
			this.left.toInorderList(list);
			list.add(this.data);
			this.right.toInorderList(list);
		}

		public void toPreorderList(ArrayList<String> list) {
			if (this == NULL_NODE) {
				return;
			}
			list.add(this.data);
			this.left.toPreorderList(list);
			this.right.toPreorderList(list);
		}

		// -------------------------------------------------------------

		public Node insert(String e) {
			if (this == NULL_NODE) {
				return new Node(e);
			} else if (e.compareTo(this.data) < 0) {
				this.left = this.left.insert(e);
			} else if (e.compareTo(this.data) > 0) {
				this.right = this.right.insert(e);
			} else {
				// do nothing - do not insert a duplicate
			}
			return this;
		}
		
		public void displayTree(int currentDepth) {
			if (this != NULL_NODE) {
				this.right.displayTree(currentDepth + 1);
				String format = "%" + ((currentDepth * 3) + 1) + "s%s%n%n";
				System.out.printf(format, " ", this.data);
				this.left.displayTree(currentDepth + 1);				
			}
		}

		public String toIndentString(String indent) {
			if (this == NULL_NODE) {
				return indent + "NULL\n";
			}
			String myInfo = indent + String.format("%d\n", this.data);
			return myInfo + this.left.toIndentString(indent + "  ") + this.right.toIndentString(indent + "  ");
		}
	}
}