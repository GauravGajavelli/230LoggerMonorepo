package bstStarter;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.AfterClass;
import org.junit.Test;




public class Testing {

	private static int countLeftNodesAtDepthPoints = 0;
	private static int shortestWordAlongPathPoints = 0;
	private static int pruneFullSubtreeSize3Points = 0;
	

	// *************************************************************
	// JUnit helper operations
	// *************************************************************
	
	private void loadUpBst(BinarySearchTree bst1, String a1[]) {
		for (int k = 0; k < a1.length; k++) {
			bst1.insert(a1[k]);
		} // end for		
	} // loadUpBst
	
	
	// -------------------------------------------------------------

	
	@Test
	public void testCountLeftNodesAtDepthTest1() {
		BinarySearchTree bstBal = new BinarySearchTree();
		final String wellBalancedTreeData[] = { 
				"november", // root
				"foxtrot", "charlie", "juliet", "bravo", "alpha", "delta", "echo", "kilo", "hotel", "golf", "india", "lima", "mike", // left subtree
				"tango", "victor", "uniform", "yankee", "zulu", "whiskey", "xray", "romeo", "sierra", "papa", "quebec", "oscar" // right subtree
				}; 
		this.loadUpBst(bstBal, wellBalancedTreeData);
//		bstBal.d
		
		// Reasonably well balanced tree
		assertEquals(0, bstBal.countLeftNodesAtDepth(0));
		Testing.countLeftNodesAtDepthPoints += 3;
		assertEquals(1, bstBal.countLeftNodesAtDepth(1));
		assertEquals(2, bstBal.countLeftNodesAtDepth(2));
		Testing.countLeftNodesAtDepthPoints += 1;
		assertEquals(4, bstBal.countLeftNodesAtDepth(3));
		assertEquals(4, bstBal.countLeftNodesAtDepth(4));
		Testing.countLeftNodesAtDepthPoints += 2;
		assertEquals(0, bstBal.countLeftNodesAtDepth(5));
		Testing.countLeftNodesAtDepthPoints += 1;
		assertEquals(0, bstBal.countLeftNodesAtDepth(6));
		Testing.countLeftNodesAtDepthPoints += 1;
	} 
	
	@Test
	public void testCountLeftNodesAtDepthTest2() {
		BinarySearchTree bstUnBal = new BinarySearchTree();
		final String highlyUnbalancedTreeData[] = { 
				"zulu", // root
				"sierra", "yankee", "tango", "xray",  "whiskey", "uniform", "victor"
				}; 
		this.loadUpBst(bstUnBal, highlyUnbalancedTreeData);
		
		// Highly unbalanced tree
		assertEquals(0, bstUnBal.countLeftNodesAtDepth(0));
		Testing.countLeftNodesAtDepthPoints += 3;
		assertEquals(1, bstUnBal.countLeftNodesAtDepth(1));
		Testing.countLeftNodesAtDepthPoints += 1;
		assertEquals(0, bstUnBal.countLeftNodesAtDepth(2));
		assertEquals(1, bstUnBal.countLeftNodesAtDepth(3));
		assertEquals(0, bstUnBal.countLeftNodesAtDepth(4));
		Testing.countLeftNodesAtDepthPoints += 2;
		assertEquals(1, bstUnBal.countLeftNodesAtDepth(5));
		assertEquals(1, bstUnBal.countLeftNodesAtDepth(6));
		assertEquals(0, bstUnBal.countLeftNodesAtDepth(7));
		Testing.countLeftNodesAtDepthPoints += 1;
		assertEquals(0, bstUnBal.countLeftNodesAtDepth(8));
		Testing.countLeftNodesAtDepthPoints += 1;
	} 
	
	@Test
	public void testShortestWordAlongPathTest1() {
		BinarySearchTree bst = new BinarySearchTree();
		
		bst.insert("romeo");
		assertEquals("romeo", bst.shortestWordAlongPath("romeo"));
		Testing.shortestWordAlongPathPoints += 2;
		
		bst.insert("echo");
		assertEquals("romeo", bst.shortestWordAlongPath("romeo"));
		assertEquals("echo", bst.shortestWordAlongPath("echo"));
		Testing.shortestWordAlongPathPoints += 1;
		
		final String treeData[] = {
				// "romeo", //root
				// "echo",
				"bravo", "alpha", "charlie", "lima", "kilo", "papa",  // left subtree
				"tango", "whiskey", "uniform", "xray"  // right subtree
		};
		this.loadUpBst(bst, treeData);
		assertEquals("romeo", bst.shortestWordAlongPath("romeo"));
		assertEquals("echo", bst.shortestWordAlongPath("echo"));
		assertEquals("echo", bst.shortestWordAlongPath("bravo"));
		assertEquals("echo", bst.shortestWordAlongPath("alpha"));
		assertEquals("echo", bst.shortestWordAlongPath("charlie"));
		assertEquals("echo", bst.shortestWordAlongPath("lima"));
		assertEquals("echo", bst.shortestWordAlongPath("kilo"));
		assertEquals("echo", bst.shortestWordAlongPath("papa"));
		Testing.shortestWordAlongPathPoints += 1;
		
		assertEquals("romeo", bst.shortestWordAlongPath("tango"));
		assertEquals("romeo", bst.shortestWordAlongPath("whiskey"));
		assertEquals("romeo", bst.shortestWordAlongPath("uniform"));
		assertEquals("xray", bst.shortestWordAlongPath("xray"));		
		Testing.shortestWordAlongPathPoints += 1;
				
		bst.insert("zoo");
		assertEquals("zoo", bst.shortestWordAlongPath("zoo"));		
		Testing.shortestWordAlongPathPoints += 1;
	}
	
	@Test
	public void testShortestWordAlongPathTest2() {
		BinarySearchTree bst = new BinarySearchTree();
		
		//None of these items searched for are in the tree.
		
		bst.insert("romeo");
		assertEquals("romeo", bst.shortestWordAlongPath("echo"));
				
		bst.insert("echo");
		assertEquals("echo", bst.shortestWordAlongPath("alpha"));
		assertEquals("romeo", bst.shortestWordAlongPath("xray"));
		Testing.shortestWordAlongPathPoints += 2;
		
		final String treeData[] = {
				// "romeo", //root
				// "echo",
				"bravo", "alpha", "charlie", "lima", "kilo", "papa",  // left subtree
				"tango", "whiskey", "uniform", "xray"  // right subtree
		};
		this.loadUpBst(bst, treeData);
		
		assertEquals("echo", bst.shortestWordAlongPath("juliet"));
		assertEquals("romeo", bst.shortestWordAlongPath("uniform"));
		assertEquals("xray", bst.shortestWordAlongPath("zoo"));
		Testing.shortestWordAlongPathPoints += 1;
	}
	
	@Test
	public void testShortestWordAlongPathTest3() {
		BinarySearchTree bstBal = new BinarySearchTree();
		final String wellBalancedTreeData[] = { 
				"november", // root
				"foxtrot", "charlie", "juliet", "bravo", "alpha", "delta", "echo", "kilo", "hotel", "golf", "india", "lima", "mike", // left subtree
				"tango", "victor", "uniform", "yankee", "zulu", "whiskey", "xray", "romeo", "sierra", "papa", "quebec", "oscar" // right subtree
				};
		this.loadUpBst(bstBal, wellBalancedTreeData);
		
		assertEquals("november", bstBal.shortestWordAlongPath("november"));
		assertEquals("juliet", bstBal.shortestWordAlongPath("juliet"));
		assertEquals("kilo", bstBal.shortestWordAlongPath("lima"));
		assertEquals("kilo", bstBal.shortestWordAlongPath("mike"));
		Testing.shortestWordAlongPathPoints += 1;
		
		assertEquals("xray", bstBal.shortestWordAlongPath("xray"));
		assertEquals("tango", bstBal.shortestWordAlongPath("whiskey"));
		assertEquals("papa", bstBal.shortestWordAlongPath("oscar"));
		assertEquals("tango", bstBal.shortestWordAlongPath("sierra"));
		Testing.shortestWordAlongPathPoints += 2;

	} 
	
	
	
	@Test
	public void testPruneFullSubtreesSize3Test1() {
		BinarySearchTree bst = new BinarySearchTree();
		
		bst.insert("romeo");
		bst.pruneFullSubtreesSize3();
		assertEquals("[romeo]", bst.toString());
		
		bst.insert("echo");
		bst.pruneFullSubtreesSize3();
		assertEquals("[echo, romeo]", bst.toString());
		
		Testing.pruneFullSubtreeSize3Points += 2;
		
		bst.insert("tango");
		bst.pruneFullSubtreesSize3();
		assertEquals("[]", bst.toString());
		
		Testing.pruneFullSubtreeSize3Points += 2;
		
		final String resetData[] = {
				"romeo", // root
				"echo",  // left subtree
				"tango", // right subtree
		};
		bst = new BinarySearchTree();
		this.loadUpBst(bst, resetData);
		bst.insert("alpha");
		bst.pruneFullSubtreesSize3();
		assertEquals("[alpha, echo, romeo, tango]", bst.toString());
		
		bst.insert("yankee");
		bst.pruneFullSubtreesSize3();
		assertEquals("[alpha, echo, romeo, tango, yankee]", bst.toString());
		
		Testing.pruneFullSubtreeSize3Points += 1;
		
		bst.insert("lima");
		bst.pruneFullSubtreesSize3();
		assertEquals("[romeo, tango, yankee]", bst.toString());
		
		Testing.pruneFullSubtreeSize3Points += 1;
		
		final String resetData2[] = {
				"romeo", // root
				"echo", "alpha", "lima",  // left subtree
				"tango", "yankee"  // right subtree
		};
		bst = new BinarySearchTree();
		this.loadUpBst(bst, resetData2);
		bst.insert("sierra");
		bst.pruneFullSubtreesSize3();
		assertEquals("[romeo]", bst.toString());
		
		Testing.pruneFullSubtreeSize3Points += 2;
	}
	
	@Test
	public void testPruneFullSubtreesSize3Test2() {
		BinarySearchTree bst = new BinarySearchTree();
		
		bst.insert("romeo");
		bst.insert("echo");
		bst.insert("alpha");
		
		bst.pruneFullSubtreesSize3();
		assertEquals("[alpha, echo, romeo]", bst.toString());
				
		Testing.pruneFullSubtreeSize3Points += 2;
		
		bst.insert("tango");
		bst.pruneFullSubtreesSize3();
		assertEquals("[alpha, echo, romeo, tango]", bst.toString());
		
		bst.insert("whiskey");
		bst.pruneFullSubtreesSize3();
		assertEquals("[alpha, echo, romeo, tango, whiskey]", bst.toString());
		
		Testing.pruneFullSubtreeSize3Points += 1;
		
		bst.insert("xray");
		bst.pruneFullSubtreesSize3();
		assertEquals("[alpha, echo, romeo, tango, whiskey, xray]", bst.toString());
		
		bst.insert("uniform");
		bst.pruneFullSubtreesSize3();
		assertEquals("[alpha, echo, romeo, tango]", bst.toString());
		
		Testing.pruneFullSubtreeSize3Points += 1;
	}
	
	@Test
	public void testPruneFullSubtreesSize3Test3() {
		BinarySearchTree bst = new BinarySearchTree();
		
		final String treeData[] = {
				"romeo", // root
				"echo", "bravo", "alpha", "charlie", "lima", "kilo", "papa",  // left subtree
				"tango", "whiskey", "uniform", "xray"  // right subtree
		};
		this.loadUpBst(bst, treeData);
	
		bst.pruneFullSubtreesSize3();
		assertEquals("[]", bst.toString());
		Testing.pruneFullSubtreeSize3Points += 4;
	}
	
	@Test
	public void testPruneFullSubreesSize3Test4() {
		BinarySearchTree bstBal = new BinarySearchTree();
		BinarySearchTree bstUnBal = new BinarySearchTree();
		final String wellBalancedTreeData[] = { 
				"november", // root
				"foxtrot", "charlie", "juliet", "bravo", "alpha", "delta", "echo", "kilo", "hotel", "golf", "india", "lima", "mike", // left subtree
				"tango", "victor", "uniform", "yankee", "zulu", "whiskey", "xray", "romeo", "sierra", "papa", "quebec", "oscar" // right subtree
				}; 
		final String highlyUnbalancedTreeData[] = { 
				"zulu", // root
				"sierra", "yankee", "tango", "xray",  "whiskey", "uniform", "victor"
				}; 
		this.loadUpBst(bstBal, wellBalancedTreeData);
		this.loadUpBst(bstUnBal, highlyUnbalancedTreeData);
		
		final String itemsToBeRemovedFromBalTree[] = {"hotel", "golf", "india", "papa", "quebec", "oscar"};
		
		// Test on large balanced tree
		this.loadUpBst(bstBal, wellBalancedTreeData);
		ArrayList<String> inGoing = bstBal.toInorderList();
		ArrayList<String> expected = new ArrayList<>(inGoing);
		expected.removeAll(Arrays.asList(itemsToBeRemovedFromBalTree));
		
		bstBal.pruneFullSubtreesSize3();
		
		assertArrayEquals(expected.toArray(), bstBal.toInorderList().toArray());
		
		Testing.pruneFullSubtreeSize3Points += 2;
		
		inGoing = bstUnBal.toInorderList();
		expected = new ArrayList<>(inGoing);
		
		bstUnBal.pruneFullSubtreesSize3();	
		assertArrayEquals(expected.toArray(), bstUnBal.toInorderList().toArray());		
		
		Testing.pruneFullSubtreeSize3Points += 2;
	}
		
	// -------------------------------------------------------------


	@AfterClass
	public static void displayPoints() {
		System.out.printf("%2d/16 countLeftNodesAtDepth correctness points\n", Testing.countLeftNodesAtDepthPoints);

		System.out.printf("%2d/12 shortestWordAlongPath correctness points\n", Testing.shortestWordAlongPathPoints);

		System.out.printf("%2d/20 pruneFullSubtreeSize3 correctness points\n", Testing.pruneFullSubtreeSize3Points);
		System.out.printf(" ?/ 8 shortestWordAlongPath efficiency will be checked by the instructor\n");
		System.out.printf(" ?/ 4 Overall correctness and elegance will be double checked by the instructor.\n");	
		System.out.printf("      Your implementation will not earn full credit if defects are detected in your code \n");	
		System.out.printf("      even if your code passed all the provided test cases.\n");	
		System.out.printf("      Remember: 'correctness is king'\n");	
	}
}