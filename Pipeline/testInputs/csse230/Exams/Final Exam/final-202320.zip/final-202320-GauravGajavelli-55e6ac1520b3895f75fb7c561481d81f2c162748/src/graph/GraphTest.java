package graph;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.AfterClass;
import org.junit.Test;

public class GraphTest {

	private static int graphALPoints = 0;
	private static int graphAMPoints = 0;
	private static Set<String> allBalloonsExample0;
	private static Set<String> allBalloonsExample1;
	private static Set<String> allBalloonsExample2;

	
	private Graph<String> buildExample0(boolean adjList) {
		// Smaller version of the example in the document
		// Only includes A, B, C, and E
		Graph<String> g;
		allBalloonsExample0 = new HashSet<String>();
		

		allBalloonsExample0.add("A");
		allBalloonsExample0.add("B");
		allBalloonsExample0.add("C");
		allBalloonsExample0.add("E");
		
		if (adjList) {
			g = new AdjacencyListGraph<String>(allBalloonsExample0);
		} else {
			g = new AdjacencyMatrixGraph<String>(allBalloonsExample0);
		}
		
		g.addEdge("A", "B");
		g.addEdge("B", "C");
		g.addEdge("B", "E");
		g.addEdge("C", "B");
		return g;
	}
	
	@Test
	public void testExample0_AllNone_AL() {
		Graph<String> g = buildExample0(true);
		Set<String> confirmedBalloons, unknownBalloons;
		
		// All balloons are Confirmed
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("A");
		confirmedBalloons.add("B");
		confirmedBalloons.add("C");
		confirmedBalloons.add("E");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample0);
		assertEquals(0, unknownBalloons.size());
		
		// No balloons are confirmed
		confirmedBalloons.clear();
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample0);
		assertEquals(4, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("B"));
		assertTrue(unknownBalloons.contains("C"));
		assertTrue(unknownBalloons.contains("E"));
		graphALPoints += 1;

	}
	
	@Test
	public void testExample0_AllNone_AM() {
		Graph<String> g = buildExample0(false);
		Set<String> confirmedBalloons, unknownBalloons;
		
		// All balloons are Confirmed
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("A");
		confirmedBalloons.add("B");
		confirmedBalloons.add("C");
		confirmedBalloons.add("E");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample0);
		assertEquals(0, unknownBalloons.size());
		
		// No balloons are confirmed
		confirmedBalloons.clear();
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample0);
		assertEquals(4, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("B"));
		assertTrue(unknownBalloons.contains("C"));
		assertTrue(unknownBalloons.contains("E"));
		graphAMPoints += 1;
	}
	
	@Test
	public void testExample0_AllInNetwork_AL() {
		Graph<String> g = buildExample0(true);
		Set<String> confirmedBalloons, unknownBalloons;
		
		// Solo balloons, A and E, are confirmed
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("A");
		confirmedBalloons.add("E");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample0);
		assertEquals(2, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("B"));
		assertTrue(unknownBalloons.contains("C"));
		
		// Networked balloons B and C are confirmed
		confirmedBalloons.clear();
		confirmedBalloons.add("B");
		confirmedBalloons.add("C");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample0);
		assertEquals(2, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("E"));
		graphALPoints += 1;
	}
	
	@Test
	public void testExample0_AllInNetwork_AM() {
		Graph<String> g = buildExample0(false);
		Set<String> confirmedBalloons, unknownBalloons;
		

		// Solo balloons, A and E, are confirmed
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("A");
		confirmedBalloons.add("E");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample0);
		assertEquals(2, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("B"));
		assertTrue(unknownBalloons.contains("C"));
		
		// Networked balloons B and C are confirmed
		confirmedBalloons.clear();
		confirmedBalloons.add("B");
		confirmedBalloons.add("C");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample0);
		assertEquals(2, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("E"));
		graphAMPoints += 1;
	}
	
	@Test
	public void testExample0_OnlyOnConfirmed_AL() {
		Graph<String> g = buildExample0(true);
		Set<String> confirmedBalloons, unknownBalloons;
		
		// Find the network of B and C, so flagging just one should mark both as OK
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("B");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample0);
		assertEquals(2, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("E"));

		// Find the network of B and C, so flagging just one should mark both as OK
		confirmedBalloons.clear();
		confirmedBalloons.add("C");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample0);
		assertEquals(2, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("E"));
		graphALPoints += 2;

	}
	
	@Test
	public void testExample0_OnlyOneConfirmed_AM() {
		Graph<String> g = buildExample0(false);
		Set<String> confirmedBalloons, unknownBalloons;
				
		// Find the network of B and C, so flagging just one should mark both as OK
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("B");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample0);
		assertEquals(2, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("E"));

		// Find the network of B and C, so flagging just one should mark both as OK
		confirmedBalloons.clear();
		confirmedBalloons.add("C");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample0);
		assertEquals(2, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("E"));
		graphAMPoints += 2;
	}
	
	
	

	private Graph<String> buildExample1(boolean adjList) {
		// This is the example in the specification. Labels are strings. 
		Graph<String> g;
		allBalloonsExample1 = new HashSet<String>();
		

		allBalloonsExample1.add("A");
		allBalloonsExample1.add("B");
		allBalloonsExample1.add("C");
		allBalloonsExample1.add("D");
		allBalloonsExample1.add("E");
		allBalloonsExample1.add("F");
		allBalloonsExample1.add("G");
		allBalloonsExample1.add("H");
		allBalloonsExample1.add("I");
		
		if (adjList) {
			g = new AdjacencyListGraph<String>(allBalloonsExample1);
		} else {
			g = new AdjacencyMatrixGraph<String>(allBalloonsExample1);
		}
		
		g.addEdge("A", "B");
		g.addEdge("B", "C");
		g.addEdge("B", "E");
		g.addEdge("C", "B");
		g.addEdge("C", "D");
		g.addEdge("D", "A");
		g.addEdge("E", "F");
		g.addEdge("F", "E");
		g.addEdge("G", "H");
		g.addEdge("H", "G");
		return g;
	}
	
	@Test
	public void testExample1_AllInNetwork_AL() {
		Graph<String> g = buildExample1(true);
		Set<String> confirmedBalloons, unknownBalloons;
		
		// All balloons in certain networks are confirmed - Round 1
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("E");
		confirmedBalloons.add("F");
		confirmedBalloons.add("G");
		confirmedBalloons.add("H");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(5, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("B"));
		assertTrue(unknownBalloons.contains("C"));
		assertTrue(unknownBalloons.contains("D"));
		assertTrue(unknownBalloons.contains("I"));

		// All balloons in certain networks are confirmed - Round 2
		confirmedBalloons.clear();
		confirmedBalloons.add("A");
		confirmedBalloons.add("B");
		confirmedBalloons.add("C");
		confirmedBalloons.add("D");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(5, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("E"));
		assertTrue(unknownBalloons.contains("F"));
		assertTrue(unknownBalloons.contains("G"));
		assertTrue(unknownBalloons.contains("H"));
		assertTrue(unknownBalloons.contains("I"));
		graphALPoints += 1;
	}
	
	@Test
	public void testExample1_AllInNetwork_AM() {
		Graph<String> g = buildExample1(false);
		Set<String> confirmedBalloons, unknownBalloons;
		
		// All balloons in certain networks are confirmed - Round 1
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("E");
		confirmedBalloons.add("F");
		confirmedBalloons.add("G");
		confirmedBalloons.add("H");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(5, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("B"));
		assertTrue(unknownBalloons.contains("C"));
		assertTrue(unknownBalloons.contains("D"));
		assertTrue(unknownBalloons.contains("I"));

		// All balloons in certain networks are confirmed - Round 2
		confirmedBalloons.clear();
		confirmedBalloons.add("A");
		confirmedBalloons.add("B");
		confirmedBalloons.add("C");
		confirmedBalloons.add("D");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(5, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("E"));
		assertTrue(unknownBalloons.contains("F"));
		assertTrue(unknownBalloons.contains("G"));
		assertTrue(unknownBalloons.contains("H"));
		assertTrue(unknownBalloons.contains("I"));
		graphAMPoints += 1;
	}
	
	@Test
	public void testExample1_OnlyOneConfirmed_AL() {
		Graph<String> g = buildExample1(true);
		Set<String> confirmedBalloons, unknownBalloons;
		
		// Only one balloon in one network is confirmed - Round 1
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("E");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(7, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("B"));
		assertTrue(unknownBalloons.contains("C"));
		assertTrue(unknownBalloons.contains("D"));
		assertTrue(unknownBalloons.contains("G"));
		assertTrue(unknownBalloons.contains("H"));
		assertTrue(unknownBalloons.contains("I"));

		// Only one balloon in one network is confirmed - Round 2
		confirmedBalloons.clear();
		confirmedBalloons.add("A");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(5, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("E"));
		assertTrue(unknownBalloons.contains("F"));
		assertTrue(unknownBalloons.contains("G"));
		assertTrue(unknownBalloons.contains("H"));
		assertTrue(unknownBalloons.contains("I"));
		
		// Only one balloon in one network is confirmed - Round 3
		confirmedBalloons.clear();
		confirmedBalloons.add("D");
		confirmedBalloons.add("F");
		confirmedBalloons.add("H");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(1, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("I"));
		graphALPoints += 1;		
	}
	

	
	@Test
	public void testExample1_OnlyOneConfirmed_AM() {
		Graph<String> g = buildExample1(false);
		Set<String> confirmedBalloons, unknownBalloons;
		
		// Only one balloon in one network is confirmed - Round 1
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("E");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(7, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("B"));
		assertTrue(unknownBalloons.contains("C"));
		assertTrue(unknownBalloons.contains("D"));
		assertTrue(unknownBalloons.contains("G"));
		assertTrue(unknownBalloons.contains("H"));
		assertTrue(unknownBalloons.contains("I"));

		// Only one balloon in one network is confirmed - Round 2
		confirmedBalloons.clear();
		confirmedBalloons.add("A");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(5, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("E"));
		assertTrue(unknownBalloons.contains("F"));
		assertTrue(unknownBalloons.contains("G"));
		assertTrue(unknownBalloons.contains("H"));
		assertTrue(unknownBalloons.contains("I"));
		
		// Only one balloon in one network is confirmed - Round 3
		confirmedBalloons.clear();
		confirmedBalloons.add("D");
		confirmedBalloons.add("F");
		confirmedBalloons.add("H");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(1, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("I"));
		graphAMPoints += 1;
	}
	
	@Test
	public void testExample1_Multiple_AL() {
		Graph<String> g = buildExample1(true);
		Set<String> confirmedBalloons, unknownBalloons;
		
		// Multiple (but not all) balloons in one network is confirmed
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("B");
		confirmedBalloons.add("C");
		confirmedBalloons.add("D");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(5, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("E"));
		assertTrue(unknownBalloons.contains("F"));
		assertTrue(unknownBalloons.contains("G"));
		assertTrue(unknownBalloons.contains("H"));
		assertTrue(unknownBalloons.contains("I"));
		graphALPoints += 1;			
	}
	
	@Test
	public void testExample1_Multiple_AM() {
		Graph<String> g = buildExample1(false);
		Set<String> confirmedBalloons, unknownBalloons;
		
		// Multiple (but not all) balloons in one network is confirmed
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("B");
		confirmedBalloons.add("C");
		confirmedBalloons.add("D");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(5, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("E"));
		assertTrue(unknownBalloons.contains("F"));
		assertTrue(unknownBalloons.contains("G"));
		assertTrue(unknownBalloons.contains("H"));
		assertTrue(unknownBalloons.contains("I"));
		graphAMPoints += 1;		
	}
	
	@Test
	public void testExample1_Solo_AL() {
		Graph<String> g = buildExample1(true);
		Set<String> confirmedBalloons, unknownBalloons;
		
		// Only one solo balloon is confirmed
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("I");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(8, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("B"));
		assertTrue(unknownBalloons.contains("C"));
		assertTrue(unknownBalloons.contains("D"));
		assertTrue(unknownBalloons.contains("E"));
		assertTrue(unknownBalloons.contains("F"));
		assertTrue(unknownBalloons.contains("G"));
		assertTrue(unknownBalloons.contains("H"));
		graphALPoints += 1;
		
	}
	
	
	@Test
	public void testExample1_AM() {
		Graph<String> g = buildExample1(false);
		Set<String> confirmedBalloons, unknownBalloons;
		
		// Only one solo balloon is confirmed
		confirmedBalloons = new HashSet<String>();
		confirmedBalloons.add("I");
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample1);
		assertEquals(8, unknownBalloons.size());
		assertTrue(unknownBalloons.contains("A"));
		assertTrue(unknownBalloons.contains("B"));
		assertTrue(unknownBalloons.contains("C"));
		assertTrue(unknownBalloons.contains("D"));
		assertTrue(unknownBalloons.contains("E"));
		assertTrue(unknownBalloons.contains("F"));
		assertTrue(unknownBalloons.contains("G"));
		assertTrue(unknownBalloons.contains("H"));
		graphAMPoints += 1;
	}
	
	
	
	
	private Graph<String> buildExample2(boolean adjList) {
		// In this example, balloon "names" are just their integer ID numbers from 0-199.
		// All balloons are networked to the next highest balloon, and balloon 199 networks back to 0.
		Graph<String> g;
		allBalloonsExample2 = new HashSet<String>();
		for (int i = 0; i < 200; i++) {
			allBalloonsExample2.add(String.valueOf(i));
		}
		if (adjList) {
			g = new AdjacencyListGraph<String>(allBalloonsExample2);
		} else {
			g = new AdjacencyMatrixGraph<String>(allBalloonsExample2);
		}
		
		// Group 2
		for (int k = 0; k < 199; k++) {
			g.addEdge(String.valueOf(k), String.valueOf(k+1));
		}
		g.addEdge(String.valueOf(199), String.valueOf(0));
		
		return g;
	}
	
	@Test
	public void testExample2_AL() {
		Graph<String> g = buildExample2(true);
		Set<String> confirmedBalloons, unknownBalloons;
		
		confirmedBalloons = new HashSet<String>();
		// Confirming one, so all should be confirmed 
		confirmedBalloons.add(String.valueOf(199));
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample2);
		assertEquals(0, unknownBalloons.size());
		
		confirmedBalloons.clear();
		// No balloons confirmed, so they should all be unknown
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample2);
		assertEquals(200, unknownBalloons.size());
		for (int k = 0; k < 200; k++) {
			assertTrue(unknownBalloons.contains(String.valueOf(k)));
		}
		graphALPoints += 2;
	}
	
	@Test
	public void testExample2_AM() {
		Graph<String> g = buildExample2(false);
		Set<String> confirmedBalloons, unknownBalloons;
		
		confirmedBalloons = new HashSet<String>();
		// Confirming one, so all should be confirmed 
		confirmedBalloons.add(String.valueOf(199));
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample2);
		assertEquals(0, unknownBalloons.size());
		
		confirmedBalloons.clear();
		// No balloons confirmed, so they should all be unknown
		unknownBalloons = g.findUnknownBalloons(confirmedBalloons, allBalloonsExample2);
		assertEquals(200, unknownBalloons.size());
		for (int k = 0; k < 200; k++) {
			assertTrue(unknownBalloons.contains(String.valueOf(k)));
		}
		graphAMPoints += 2;
	}

	@AfterClass
	public static void displayPoints() {
		System.out.println("----------------------------------------------------------------------");
		System.out.printf("3. %2d/10  Graph (AL) points        \n", graphALPoints);
		System.out.printf("   %2d/10  Graph (AM) points        \n", graphAMPoints);
	}

}
