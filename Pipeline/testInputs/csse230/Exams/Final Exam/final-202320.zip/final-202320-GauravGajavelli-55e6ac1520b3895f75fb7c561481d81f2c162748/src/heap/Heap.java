package heap;


public class Heap {

	// Note:
	// For this exam question, we are setting the INITIAL_CAPACITY large
	// so that we never have to grow the array
	//
	// All JUnit tests are written so as not to violate the heap's array capacity
	private static final int INITIAL_CAPACITY = 100;
	
	public int[] heap;
	public int heapSize;
	
	public Heap(int[] initialMinHeapData, int initialHeapSize) {
		this.heap = new int[INITIAL_CAPACITY];
		this.heapSize = initialHeapSize;
		
		// Note: we are observing the convention of having the heap begin at index = 1
		for (int k = 1; k <= initialHeapSize; k++) {
			this.heap[k] = initialMinHeapData[k];
		}
	}
	
	// You are free to add other helper methods here
	
	/*
	 * Merge (combine) items from otherMinHeap into this.heap
	 * After merging, this.heap must be a min heap.
	 * 
	 * MergeInto would be used when merging two priority queues together
	 */
	public void mergeInto(int[] otherMinHeap, int otherMinHeapSize) {
		//TODO: Implement this method
	}
	
	@Override
	public String toString() {
		//TODO: Implement this method
		return "";
	}

}
