package heap;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.AfterClass;
import org.junit.Test;


// Test class
public class HeapTest {

	private static int heapPoints = 0;
	
	
	private boolean isCheckAncestors(int[] heap, int checkLoc) {
		if (checkLoc <= 1) {
			return true;
		} else {
			int parent = checkLoc / 2;
			return (heap[checkLoc]> heap[parent]) && this.isCheckAncestors(heap, parent);
		}
	}
	
	private boolean isMinHeap(int[] heap, int heapSize) {
		int k = heapSize;
		while ((k > 1) && this.isCheckAncestors(heap, k)) {
			k--;
		}
		return k == 1;
	}
	
	private boolean containsAll(int[] heap, int heapSize, ArrayList<Integer> expected) {
		ArrayList<Integer> actual = new ArrayList<Integer>();
		for (int k = 1; k <= heapSize; k++) {
			actual.add(heap[k]);
		}
		return expected.containsAll(actual) && actual.containsAll(expected);
	}
	
	// **********************************************************************************
	@Test
	public void testToString() {
		// Note: the values in this heap starts at index = 1
		
		int[] initialMinHeap = {0, 4, 15, 10, 45, 30, 21, 100, 48};
		Heap minHeap = new Heap(initialMinHeap, 8);
		assertEquals("[4, 15, 10, 45, 30, 21, 100, 48]", minHeap.toString());
		heapPoints += 3;
	}
	
	@Test
	public void testMergeInto() {
		// Note: the values in each heap starts at index = 1
		
		int[] initialMinHeap = {0, 4, 15, 10, 45, 30, 21, 100, 48};
		Heap minHeap = new Heap(initialMinHeap, 8);
		
		int otherHeap[] = {0, 11, 43, 100, 77, 48, 111};
		ArrayList<Integer> expected = new ArrayList<Integer>(Arrays.asList(4, 15, 10, 45, 30, 21, 100, 48, 11, 43, 100, 77, 48, 111));
		
		minHeap.mergeInto(otherHeap, 6);
		
		// Merged heap size test
		assertEquals (14, minHeap.heapSize);
		heapPoints += 2;
		
		// Make sure all items are in the merged heap
		String expectedMsg = "\nexpected merged heap to contain all of the following: \n" + Arrays.toString(expected.toArray());
		assertTrue (expectedMsg, this.containsAll(minHeap.heap, minHeap.heapSize, expected));
		heapPoints += 5;
		
		// Make sure merged heap is a min heap
		assertTrue("expected is min heap: true", this.isMinHeap(minHeap.heap, minHeap.heapSize));
		heapPoints += 5;
	}	
	
	@AfterClass
	public static void displayPoints() {
		System.out.println("----------------------------------------------------------------------");
		System.out.printf("2. %2d/15  heap points\n", heapPoints);
	}
}
