package tree;

/**
 * An implementation of a binary search tree, containing Integer data.
 */
public class BinarySearchTree {

	private BinaryNode root;
	private final BinaryNode NULL_NODE = new BinaryNode(null);

	public BinarySearchTree() {
		root = NULL_NODE;
	}

	/* To Do: implement countOddOnlyIf
	 * 
	 * countOddOnlyIf - make a count of all nodes in the tree rooted at 'root'
	 * but count the node only if the node's value is odd and 
	 * the node's height(left) < node's height(right)
	 */
	public Integer countOddOnlyIf() {
		//TODO: Implement this method
		return -1;
	}

	// The next methods are used by the unit tests
	public void insert(Integer e) {
		root = root.insert(e);
	}

	// You can use this to see in-order traversal
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		root.toString(sb);
		return sb.toString();
	}


	// ----------------------------
	// /////////////// BinaryNode
	// ----------------------------
	public class BinaryNode {
		public Integer data;
		public BinaryNode left;
		public BinaryNode right;

		public BinaryNode(Integer element) {
			this.data = element;
			this.left = NULL_NODE;
			this.right = NULL_NODE;
		}

		/* Add any additional methods here */
		

		// The rest of the methods are used by the unit tests and for debugging
		public BinaryNode insert(Integer e) {
			if (this == NULL_NODE) {
				return new BinaryNode(e);
			} else if (e < data) {
				left = left.insert(e);
			} else if (e > data) {
				right = right.insert(e);
			} else {
				// do nothing
			}
			return this;
		}

		public void toString(StringBuilder sb) {
			if (this == NULL_NODE) {
				return;
			}
			left.toString(sb);
			sb.append(this.data.toString());
			right.toString(sb);
		}

	}
}