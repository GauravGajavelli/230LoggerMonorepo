package tree;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Test;

public class TreeTest {
	private static int treePoints = 0;
	
	
	
	@Test
	public void testCountOddOnlyIfN01() {
		// Empty Tree
		BinarySearchTree t = new BinarySearchTree();
		assertEquals((Integer)0, t.countOddOnlyIf());
		treePoints += 1;
	}
	
	@Test
	public void testCountOddOnlyIfN02() {
		// |t| = 1
		BinarySearchTree t = new BinarySearchTree();
		t.insert(81);
		assertEquals((Integer)0, t.countOddOnlyIf());
		treePoints += 1;
	}
	
		@Test
	public void testCountOddOnlyIfN03() {
		//     81
		//    /
		//   20
		BinarySearchTree t = new BinarySearchTree();
		t.insert(81);
		t.insert(20);
		assertEquals((Integer)0, t.countOddOnlyIf());
		treePoints += 1;
	}
	
	@Test
	public void testCountOddOnlyIfN04() {
		//     81
		//       \
		//       101
		BinarySearchTree t = new BinarySearchTree();
		t.insert(81);
		t.insert(101);
		assertEquals((Integer)1, t.countOddOnlyIf());
		treePoints += 1;
	}
	
	@Test
	public void testCountOddOnlyIfN05() {
		//     80
		//       \
		//       101
		BinarySearchTree t = new BinarySearchTree();
		t.insert(80);
		t.insert(101);
		assertEquals((Integer)0, t.countOddOnlyIf());
		treePoints += 1;
	}
	
	@Test
	public void testCountOddOnlyIfN06() {
		//     81
		//    /  \
		//   5   101
		BinarySearchTree t = new BinarySearchTree();
		t.insert(81);
		t.insert(5);
		t.insert(101);
		assertEquals((Integer)0, t.countOddOnlyIf());
		treePoints += 1;
	}
	
	@Test
	public void testCountOddOnlyIfN07() {
		//     81
		//    /  \
		//   5   101
		//         \
		//         105
		BinarySearchTree t = new BinarySearchTree();
		t.insert(81);
		t.insert(5);
		t.insert(101);
		t.insert(105);
		assertEquals((Integer)2, t.countOddOnlyIf());
		treePoints += 1;
	}
	
	@Test
	public void testCountOddOnlyIfN08() {
		//     81
		//    /  \
		//   5   101
		//    \    \
		//    19   105
		BinarySearchTree t = new BinarySearchTree();
		t.insert(81);
		t.insert(5);
		t.insert(101);
		t.insert(19);
		t.insert(105);		
		assertEquals((Integer)2, t.countOddOnlyIf());
		treePoints += 2;
	}
	
	@Test
	public void testCountOddOnlyIfN09() {
		//     81 
		//    /  \  
		//   5   101
		//    \    \
		//    19   105
		//      \ 
		//      23
		BinarySearchTree t = new BinarySearchTree();
		t.insert(81);
		t.insert(5);
		t.insert(101);
		t.insert(19);
		t.insert(105);
		t.insert(23);		
		assertEquals((Integer)3, t.countOddOnlyIf());
		treePoints += 2;
	}
	
	@Test
	public void testCountOddOnlyIfN10() {
		//     81 
		//    /  \  
		//   4   100
		//    \    \
		//    18   105
		//      \ 
		//      21
		BinarySearchTree t = new BinarySearchTree();
		t.insert(81);
		t.insert(4);
		t.insert(100);
		t.insert(18);
		t.insert(105);
		t.insert(21);
		assertEquals((Integer)0, t.countOddOnlyIf());
		treePoints += 2;
	}
	
	@Test
	public void testCountOddOnlyIfN11() {
		//               27             
		//            /     \            
		//          20       55        
		//         /       /    \      
		//       16      40      61   
		//      /       /  \    /  \  
		//     8      32    42 57   63
		//                            \
		//                             65
		BinarySearchTree t = new BinarySearchTree();
		t.insert(27);
		t.insert(20);
		t.insert(55);
		t.insert(16);
		t.insert(40);
		t.insert(61);
		t.insert(8);
		t.insert(32);
		t.insert(42);
		t.insert(57);
		t.insert(63);
		t.insert(65);
		assertEquals((Integer)4, t.countOddOnlyIf());
		treePoints += 2;
	}

	@AfterClass
	public static void displayPoints() {
		System.out.println("----------------------------------------------------------------------");
		System.out.printf("1. %2d/15  countOddOnlyIf correctness points                     \n", treePoints);
		System.out.printf("    ?/10  countOddOnlyIf efficiency/elegance points (manually graded) \n");
	}
}
