# TreePracticeHW5
Starter code for the tree practice in homework 5
