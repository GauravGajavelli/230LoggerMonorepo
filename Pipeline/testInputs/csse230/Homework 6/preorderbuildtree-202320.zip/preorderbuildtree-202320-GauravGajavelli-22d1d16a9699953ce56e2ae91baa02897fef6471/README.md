# PreorderBuildTree
Starting code for homework 6
